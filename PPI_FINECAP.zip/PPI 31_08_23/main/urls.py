
from django.contrib import admin
from django.urls import path 
from FINECAP.views import index, listar_reserva, criar_reserva, editar_reserva, excluir_reserva, detalhar_reserva

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',index,name='index'),
    path('reserva/listar',listar_reserva,name='listar_reserva'),
    path('reserva/',criar_reserva,name='criar_reserva'),
    path('reserva/editar/<int:id>/', editar_reserva, name='editar_reserva'),
    path('reserva/remover/<int:id>/',excluir_reserva,name='excluir_reserva'),
    path('reserva/detalhar',detalhar_reserva,name='detalhar_reserva'),

    
]
