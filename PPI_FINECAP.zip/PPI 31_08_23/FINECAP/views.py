from django.shortcuts import render,get_object_or_404,redirect
from .models import Reserva, Stand
from .form import ReservaForm, StandForm

def index(request):
    total_reservas = Reserva.objects.count()
    total_stands = Stand.objects.count()
    context = {
        'total_reservas' : total_reservas,
        'total_stands' : total_stands
    }
    return render(request, "FINECAP/index.html",context)


def listar_reserva(request):
    reservas = Reserva.objects.all()
    context ={
        'reservas':reservas
    }
    return render(request, "reserva/reservas.html",context)

def criar_reserva(request):
    if request.method == 'POST':
        form = ReservaForm(request.POST) 
        if form.is_valid(): 
            form.save() 
            form = ReservaForm() 
    else:
        form = ReservaForm()

    return render(request, "reserva/form.html", {'form': form})
#---------------------------------------------------------#
def editar_reserva(request,id):
    reserva = get_object_or_404(Reserva,id=id) 
   
    if request.method == 'POST':
        form = ReservaForm(request.POST,instance=reserva)

        if form.is_valid():
            form.save()
            return redirect('listar_reserva')
    else:
        form = ReservaForm(instance=reserva) 

    return render(request,'reserva/form.html',{'form':form})


def excluir_reserva(request, id):
    reserva = get_object_or_404(Reserva, id=id)
    reserva.delete()
    return redirect('listar_reserva') 

def detalhar_reserva(request):
    reservas = Reserva.objects.all()
    context ={
        'reservas':reservas
    }
    return render(request, "reserva/detalhe.html",context)

